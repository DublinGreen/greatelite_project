<?php
    echo("FUCKER");
    // create curl resource
    //$ch = curl_init();

    // set url
    //curl_setopt($ch, CURLOPT_URL, 'https://greatelites.com/matchTest');

    //return the transfer as a string
    //curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    // $output contains the output string
    //$output  = "sent_registration_email";
    //$output = curl_exec($ch);

    // close curl resource to free up system resources
    //curl_close($ch);
    
?>