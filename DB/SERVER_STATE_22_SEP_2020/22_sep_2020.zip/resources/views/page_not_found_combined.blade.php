@extends('layouts.page_layout')

@section('header')
    @include('page-not-found-pages.header')
@stop

@section('body')
    @include('page-not-found-pages.404')
@stop
