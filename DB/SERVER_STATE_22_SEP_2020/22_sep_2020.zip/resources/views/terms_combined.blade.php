@extends('layouts.home_layout')

@section('header')
@include('home-pages.home_header')
@stop

@section('nav')
@include('home-pages.home_nav')
@stop

@section('body')
@include('home-pages.terms')
@stop

@section('footer')
@include('home-pages.home_footer')
@stop