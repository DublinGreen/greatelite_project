@yield('header')
@yield('nav')
@yield('body')
@yield('footer')