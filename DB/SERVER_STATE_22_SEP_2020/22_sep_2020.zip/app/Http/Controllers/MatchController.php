<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Mail\Mailer;
use App\Http\Requests;
use Log;

use App\User;
use App\PledgeOptions;
use App\Ledger;
use App\Pledges;
use App\PledgeTracker;
use App\BankAccount;
use Sms\EbulkSms;
use DB;
use Validator;

require(__DIR__ . '/../../EbulkSms.php');

class MatchController extends Controller
{
    private $predefinedData;

    private function sendMergedSms($user)
    {
        $username = env('SMS_USERNAME');
        $apikey = env('SMS_API_KEY');
        $sendername = env('SMS_TITLE');
        $recipients = $user->mobile;
        $flash = 0;
        $appName = env('APP_NAME');
        $composedMessage = "{$user->first_name} you have been merged to make payment. Login into your Greatelite account for user details.";
        //echo ($composedMessage);
        $message = substr($composedMessage, 0, 160); //Limit this message to one page.
        // $sms = new EbulkSms();

        #Use the next line for HTTP POST with JSON
        // $result = $sms->useJSON(env('SMS_JSON_URL'), $username, $apikey, $flash, $sendername, $message, $recipients);
    }

    private function sendRecommitSms($user)
    {
        $username = env('SMS_USERNAME');
        $apikey = env('SMS_API_KEY');
        $sendername = env('SMS_TITLE');
        $recipients = $user->mobile;
        $flash = 0;
        $appName = env('APP_NAME');
        $composedMessage = "{$user->first_name} your pledge is due. You need to recommit and fulfill another pledge. To be withdraw due pledge.";
        //echo ($composedMessage);
        $message = substr($composedMessage, 0, 160); //Limit this message to one page.
        $sms = new EbulkSms();

        #Use the next line for HTTP POST with JSON
        $result = $sms->useJSON(env('SMS_JSON_URL'), $username, $apikey, $flash, $sendername, $message, $recipients);
    }

    private function missedMergedOpportunityNotPaidRegistrationFee($user)
    {
        $username = env('SMS_USERNAME');
        $apikey = env('SMS_API_KEY');
        $sendername = env('SMS_TITLE');
        $recipients = $user->mobile;
        $flash = 0;
        $appName = env('APP_NAME');
        $composedMessage = "{$user->first_name} you have been missed a merge opportunity because you not paid the registration fee.";
        //echo ($composedMessage);
        $message = substr($composedMessage, 0, 160); //Limit this message to one page.
        $sms = new EbulkSms();


        if ($user->send_missed_merged_sms == 'NO') {
            #Use the next line for HTTP POST with JSON
            // $result = $sms->useJSON(env('SMS_JSON_URL'), $username, $apikey, $flash, $sendername, $message, $recipients);
            $user->send_missed_merged_sms = 'YES';
            $user->save();
        }
    }


    private function matchToAReceiverThatHasNotPaidAnyAmount()
    {
        // Log::info('Running job to matchToReceive');

        $toReceive = null;
        $userToReceive = null;
        $status = 'PAID';
        $currentDate = date("Y-m-d H:i:s", strtotime("now"));
        $nextDate = date("Y-m-d H:i:s", strtotime("+1 day"));
        $dueDate = date("Y-m-d H:i:s", strtotime("+5 day"));

        echo ("<br>Current Date :" . $currentDate . "<br><hr>");
        // Log::info($currentDate);
        $duePledges = Pledges::where('status', '=', $status)
            ->where('when_due', '<=', $currentDate)
            ->where('process', '=', 'INCOMPLETE')
            ->where('can_withdraw', '=', 'YES')
            // ->take(1)
            // ->toSql();
            ->get();

        echo ("<hr>");
        print_r($duePledges);
        echo ("<hr>");
        exit();
        // need to check if you already have a pledge paid, so withdrawal is good
        if (!empty($duePledges)) {
            // Got due pledges
            foreach ($duePledges as $pledge) {

                $toReceive = $pledge->amount + $pledge->interest + $pledge->bonus_to_collect;
                $userToReceive = User::find($pledge->user_id);

                echo ("USER ID : " . $userToReceive->id . "<br>");
                echo ("PLEDGE ID : " . $pledge->id . "<br>");
                echo ("toReceive : " . $toReceive . "<br>");
                echo ("<br><hr>");

                $usersToPayPledges = Pledges::where('status', '=', 'NOT PAYED')
                ->where('amount', '<=', $toReceive)
                // ->where('amount_paid', '!=', 0)
                ->where('amount_paid', '=', 0)
                ->where('user_id', '!=', $userToReceive->id)
                ->get();
                // ->toSql();

                echo ("<hr>");
                echo("<br>USER TO PAY<br>");
                echo("<br>$pledge->id<br>");
                // print_r($pledge);
                echo ("<hr>");
                Log::info($usersToPayPledges);
                // exit();

                echo ("<br> toReceive: $toReceive<br>");
                Log::info('<br> toReceive: toReceive<br>');
                // exit();
                if (!empty($usersToPayPledges)) {
                    // echo count($twoUsersToPayPledges);
                    static $moneyCounter = 0;
                    static $moneyFinalCounter = 0;
                    static $total = 0;
                    echo ("<br>$moneyCounter<br>");

                    foreach ($usersToPayPledges as $userToPayPledge) {
                        $moneyCounter = $userToPayPledge->amount + $moneyCounter;
                        $userToPayData = User::find($userToPayPledge->user_id);

                        if ($userToPayData->registration_fee == 'PAID' && $userToPayData->confirm_mobile == 'YES' && $userToPayData->agreed_to_terms == 'YES') {
                            if ($moneyCounter <= $toReceive) {
                                $total += $userToPayPledge->amount;

                                echo ("<br>");
                                print_r($userToPayPledge);
                                echo ("<br><hr>");

                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'amount' => $userToPayPledge->amount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $userToPayPledge->amount;
                                $userToPayPledge->status = 'PAID';
                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();
                                echo ("<br>send alert to sender {$userToPayPledge->amount}<br>");
                                // Log::info("<br>send alert to sender {$userToPayPledge->amount}<br>");

                                $userSendingMoney = User::find($userToPayPledge->user_id);
                                $this->sendMergedSms($userSendingMoney);
                            } else {
                                $lastAmount = $toReceive - $total;

                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'type' => 'PLEDGE',
                                    'amount' => $lastAmount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $lastAmount;

                                if ($lastAmount == $userToPayPledge->amount) {
                                    $userToPayPledge->status = 'PAID';
                                } else {
                                    $userToPayPledge->status = 'PAYING';
                                }

                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();

                                echo ("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                echo ("<br>total {$total}<br>");
                                // Log::info("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                // Log::info("<br>total {$total}<br>");

                                if (!empty($pledge->referrer_id) && $pledge->referrer_bonus == 0) {
                                    $userToGetBonusPledge = Pledges::where('status', '!=', 'NOT PAYED')
                                        ->where('process', '=', 'INCOMPLETE')
                                        ->where('user_id', '=', $pledge->referrer_id)
                                        ->where('referrer_bonus', '=', 0)
                                        ->get();

                                    if (!empty($userToGetBonusPledge)) {
                                        // add current bonus_to_collect and referrer_bonus
                                        $userToGetBonusPledge->bonus_to_collect = $userToGetBonusPledge->bonus_to_collect + $pledge->referrer_bonus;

                                        $pledge->paid_bonus = 'YES'; // ADDEDED BONUS USER NOT PAYED PLEDGE
                                        $pledge->save();
                                        $saved = $userToGetBonusPledge->save();
                                    }
                                }
                                $pledge->process = 'COMPLETE';

                                $pledge->save();
                                // Log::info("<br>MATCHING SUCCES<br>");
                                break;
                            }
                        } else {
                            $this->missedMergedOpportunityNotPaidRegistrationFee($userToPayData);
                        }
                    }
                }
            }
        }
    }

    private function matchToAReceiverThatHasNotPaidSomeAmount()
    {
        // Log::info('Running job to matchToReceive');

        $toReceive = null;
        $userToReceive = null;
        $status = 'PAID';
        $currentDate = date("Y-m-d H:i:s", strtotime("now"));
        $nextDate = date("Y-m-d H:i:s", strtotime("+1 day"));
        $dueDate = date("Y-m-d H:i:s", strtotime("+5 day"));

        echo ("<br>Current Date :" . $currentDate . "<br>");
        // Log::info($currentDate);
        $duePledges = Pledges::where('status', '=', $status)
            ->where('when_due', '<=', $currentDate)
            ->where('process', '=', 'INCOMPLETE')
            ->where('can_withdraw', '=', 'YES')
            ->take(1)
            // ->toSql();
            ->get();

        echo ("<hr>");
        print_r($duePledges);
        echo ("<hr>");
        // exit();
        // need to check if you already have a pledge paid, so withdrawal is good
        if (!empty($duePledges)) {
            // Got due pledges
            foreach ($duePledges as $pledge) {

                $toReceive = $pledge->amount + $pledge->interest + $pledge->bonus_to_collect;
                $userToReceive = User::find($pledge->user_id);

                $usersToPayPledges = Pledges::where('status', '!=', $status)
                    ->where('amount_paid', '<=', $toReceive)
                    ->get();
                // ->toSql();

                echo ("<hr>");
                print_r($usersToPayPledges);
                echo ("<hr>");
                Log::info($usersToPayPledges);
                // exit();

                echo ("<br> toReceive: $toReceive<br>");
                Log::info('<br> toReceive: toReceive<br>');
                if (!empty($usersToPayPledges)) {
                    // echo count($twoUsersToPayPledges);
                    static $moneyCounter = 0;
                    static $moneyFinalCounter = 0;
                    static $total = 0;
                    echo ("<br>$moneyCounter<br>");

                    foreach ($usersToPayPledges as $userToPayPledge) {
                        $moneyCounter = $userToPayPledge->amount + $moneyCounter;
                        $userToPayData = User::find($userToPayPledge->user_id);

                        if ($userToPayData->registration_fee == 'PAID' && $userToPayData->confirm_mobile == 'YES' && $userToPayData->agreed_to_terms == 'YES') {
                            if ($moneyCounter <= $toReceive) {
                                $total += $userToPayPledge->amount;
                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'amount' => $userToPayPledge->amount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $userToPayPledge->amount_paid + ($userToPayPledge->amount - $userToPayPledge->amount_paid);
                                $userToPayPledge->status = 'PAID';
                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();
                                echo ("<br>send alert to sender {$userToPayPledge->amount}<br>");
                                // Log::info("<br>send alert to sender {$userToPayPledge->amount}<br>");

                                $userSendingMoney = User::find($userToPayPledge->user_id);
                                $this->sendMergedSms($userSendingMoney);
                            } else {
                                $lastAmount = $toReceive - $total;

                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'type' => 'PLEDGE',
                                    'amount' => $lastAmount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $lastAmount;

                                if ($lastAmount == $userToPayPledge->amount) {
                                    $userToPayPledge->status = 'PAID';
                                } else {
                                    $userToPayPledge->status = 'PAYING';
                                }

                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();

                                echo ("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                echo ("<br>total {$total}<br>");
                                // Log::info("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                // Log::info("<br>total {$total}<br>");

                                if (!empty($pledge->referrer_id) && $pledge->referrer_bonus == 0) {
                                    $userToGetBonusPledge = Pledges::where('status', '!=', 'NOT PAYED')
                                        ->where('process', '=', 'INCOMPLETE')
                                        ->where('user_id', '=', $pledge->referrer_id)
                                        ->where('referrer_bonus', '=', 0)
                                        ->get();

                                    if (!empty($userToGetBonusPledge)) {
                                        // add current bonus_to_collect and referrer_bonus
                                        $userToGetBonusPledge->bonus_to_collect = $userToGetBonusPledge->bonus_to_collect + $pledge->referrer_bonus;

                                        $pledge->paid_bonus = 'YES'; // ADDEDED BONUS USER NOT PAYED PLEDGE
                                        $pledge->save();
                                        $saved = $userToGetBonusPledge->save();
                                    }
                                }
                                $pledge->process = 'COMPLETE';

                                $pledge->save();
                                // Log::info("<br>MATCHING SUCCES<br>");
                                break;
                            }
                        } else {
                            $this->missedMergedOpportunityNotPaidRegistrationFee($userToPayData);
                        }
                    }
                }
            }
        }
    }

    public function __construct()
    {
        $this->predefinedData = array(
            'appUrl' => env('APP_URL'),
            'appName' => env('APP_NAME'),
            'email' => env('EMAIL'),
            'email2' => env('EMAIL2'),
            'email3' => env('EMAIL3'),
            'telephone' => env('TELEPHONE'),
            'telephone2' => env('TELEPHONE2'),
            'telephone3' => env('TELEPHONE3'),
            'telephone4' => env('TELEPHONE4'),
            'address' => env('ADDRESS'),
            'address2' => env('ADDRESS2'),
            'address3' => env('ADDRESS3'),
            'samagolaUrl' => env('SAMAGOLA_URL'),
            'highlanderUrl' => env('HIGHLANDER_URL'),
            'smsTitle' => env('SMS_TITLE'),
            'facebook' => env('SOCIAL_FACEBOOK'),
            'twitter' => env('SOCIAL_TWITTER'),
            'instagram' => env('SOCIAL_INSTAGRAM'),
            'whatsapp' => env('SOCIAL_WHATSAPP'),
            'rss' => env('SOCIAL_RSS'),
            'canonicalUrl' => env('APP_URL'),
            'success' => false,
            'investment_duration' => env('APP_PLEDGE_DURATION'),
            'registration_fee' => env('APP_REGISTRATION_FEE'),
            'currency' => env('APP_DEFAULT_CURRENCY')
        );
    }

    private function sendSmsToUserThatPledgeIsDue()
    {

        $currentDate = date("Y-m-d H:i:s", strtotime("+ 1 hour"));
        echo ("<br>Current Date :" . $currentDate . "<br>");

        $duePledges = Pledges::where('when_due', '<=', $currentDate)
            ->where('process', '=', 'INCOMPLETE')
            ->where('can_withdraw', '=', 'NO')
            ->where('status', '=', 'PAID')
            // ->where('amount', '=', 'amount_received_and_confirmed')
            ->get();
        // >toSql();

        if (!empty($duePledges)) {
            foreach ($duePledges as $pledge) {


                if ($pledge->amount == $pledge->amount_paid_confirmed) {

                    $userToGetBonusPledge = Pledges::where('status', '!=', 'NOT PAYED')
                        ->where('process', '=', 'INCOMPLETE')
                        ->where('user_id', '=', $pledge->referrer_id)
                        ->where('referrer_bonus', '=', 0)
                        ->get();

                    if (!empty($userToGetBonusPledge[0])) {

                        $singleUserToGetBonus = $userToGetBonusPledge[0];
                        echo ("PLEDGE TO GET BONUS $singleUserToGetBonus->id ");

                        $singleUserToGetBonus->bonus_to_collect = $singleUserToGetBonus->bonus_to_collect + $pledge->referrer_bonus;

                        $singleUserToGetBonus->save();

                        $pledge->paid_bonus = 'YES';
                    }
                    $user = User::find($pledge->user_id);
                    if ($pledge->sent_recommit_sms == 'NO') {
                        $this->sendRecommitSms($user);
                        $pledge->sent_recommit_sms = 'YES';
                        
                        echo ("<br>ID : $pledge->id<br>");
                        echo ("<br>USER ID : $pledge->user_id<br>");
                        echo ("<br>Amount : $pledge->amount<br>");
                        echo ("<br>amount_paid_confirmed : $pledge->amount_paid_confirmed<br>");
                        echo ("<br> ID : $pledge->id , Referrer_id : $pledge->referrer_id <br>");
                        echo ("<hr>");
                    }


                    $pledge->save();
                }
            }
        }
    }

    public function matchTest(Request $request)
    {
        $this->sendSmsToUserThatPledgeIsDue();
        $this->matchToAReceiverThatHasNotPaidAnyAmount();
    }
}
