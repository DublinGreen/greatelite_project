<body>

    <!---Preloader Starts Here--->
    <div id="ip-container" class="ip-container">
        <header class="ip-header">
            <h1 class="ip-logo text-center"><img class="img-fluid" src="<?php echo e($appUrl); ?>assets/images/logo-c.png" alt="" class="ip-logo text-center" /></h1>
            <div class="ip-loader">
                <svg class="ip-inner" width="60px" height="60px" viewBox="0 0 80 80">
                    <path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z" />
                    <path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z" />
                </svg>
            </div>
        </header>
    </div>
    <!---Preloader Ends Here--->

    <section style="background: url(<?php echo e($appUrl); ?>assets/images/macbook-laptop-ipad-apple-38519.jpeg?w=940&amp;h=650&amp;auto=compress&amp;cs=tinysrgb);background-size: cover">
        <div class="height-100-vh bg-primary-trans">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-7 col-lg-5">
                        <div class="register-div">
                            <p class="logo mb-1"><a href="<?php echo e($appUrl); ?>" target="blank"><i class="fa fa-home"></i></a><?php echo e($appName); ?> - Register</p>
                            <p class="mb-4" style="color: #a5b5c5">Create an account.</p>

                            <?php if($success): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <p><strong>Registration Success!</strong> Confirm your email (<?php echo e($formValues['email']); ?>) by clicking the confirmation link sent.</p>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>

                            <form method="post" id="needs-validation" action="<?php echo e(url('register/')); ?>/<?php echo e($referrer); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="referrer" value="<?php echo e($referrer); ?>">

                                <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>

                                <div class="form-group">
                                    <label>First Name</label>
                                    <input value="<?php echo e($formValues['first_name']); ?>" class="form-control input-lg" name="first_name" placeholder="Enter first name" type="text" required>
                                    <div class="invalid-feedback">This field is required.</div>
                                </div>

                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input value="<?php echo e($formValues['last_name']); ?>" class="form-control input-lg" name="last_name" placeholder="Enter last name" type="text" required>
                                    <div class="invalid-feedback">This field is required.</div>
                                </div>

                                <div class="form-group">
                                    <label>Email</label>
                                    <input value="<?php echo e($formValues['email']); ?>" class="form-control input-lg" name="email" placeholder="Enter email address" type="email" required>
                                    <div class="invalid-feedback">This field is required.</div>
                                </div>

                                <div class="form-group">
                                    <label>Create Password</label>
                                    <input class="form-control input-lg" name="password" placeholder="Create strong password" type="password" required>
                                    <div class="invalid-feedback">This field is required.</div>
                                </div>

                                <div class="form-group">
                                    <label>Confirm Password</label>
                                    <input class="form-control input-lg" name="password_confirmation" placeholder="Confirm password" type="password" required>
                                    <div class="invalid-feedback">This field is required.</div>
                                </div>

                                <div class="checkbox">
                                    <label class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" required name="agreed_to_terms" value="yes">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">I agree to the <?php echo e($appName); ?> <a href="<?php echo e($appUrl); ?>terms" target="blank" class="btn-link">Terms and Privacy</a>.</span>
                                    </label>
                                </div>
                               
                                <button class="btn btn-primary mt-2">Register</button>
                                <br>
                                <small class="text-muted mb-1 d-block"><strong>Upline :</strong>  <?php echo e($uplineUserObj->first_name); ?> <?php echo e($uplineUserObj->last_name); ?></small>
                            
                                <small class="text-muted mt-5 mb-1 d-block">Already have an account? <a href="<?php echo e($appUrl); ?>login">Login Now!</a></small>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>