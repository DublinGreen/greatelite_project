<!--Page Container-->
<section class="page-container" id="profileBlock">
    <div class="page-content-wrapper">
        <!--Header Fixed-->
        <div class="header fixed-header">
            <div class="container-fluid" style="padding: 10px 25px">
                <div class="row">
                    <div class="col-9 col-md-6 d-lg-none">
                        <a id="toggle-navigation" href="javascript:void(0);" class="icon-btn mr-3"><i class="fa fa-bars"></i></a>
                        <span class="logo">Great Elites</span>
                    </div>
                    <div class="col-lg-8 d-none d-lg-block">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Great Elites <?php echo e($pageTitle); ?></a></li>
                        </ol>
                    </div>
                    <div class="col-3 col-md-6 col-lg-4">
                        <!-- <a href="javascript:void(0);" class="btn btn-primary btn-round pull-right d-none d-md-block">Buy Theme Now</a> -->
                    </div>
                </div>
            </div>
        </div>


        <!--Main Content-->
        <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title">
                            <h4>Details of User To Pay</h4>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="block form-block mb-4">
                            <div class="block-heading">
                                <h5>
                                    User To Send Money (<?php echo e($currency); ?><?php echo e(number_format($pledgeTrackerSending->amount)); ?>)
                                </h5>
                            </div>
                            <?php if($userAccountOk): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <h5 class="text-center" style="color: #ffffff"><i class="fa fa-user"></i> User Details</h5>
                                <hr>
                                <p>Name: <?php echo e($userAccount->first_name); ?> <?php echo e($userAccount->middle_name); ?> <?php echo e($userAccount->last_name); ?></p>
                                <p>Email: <?php echo e($userAccount->email); ?></p>
                                <p>Mobile: <?php echo e($userAccount->mobile); ?></p>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="block form-block mb-4">
                                        <?php if(!empty($uploadMessage)): ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <p><strong>Note : </strong> <?php echo e($uploadMessage); ?></p>
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <?php endif; ?>
                                        <form enctype="multipart/form-data" method="post" action="<?php echo e(url('viewMergedForPaying/')); ?>/<?php echo e($pledgeTrackerID); ?>">
                                            <?php if(!empty($uploadError)): ?>
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <li><?php echo e($uploadError); ?></li>
                                                </ul>
                                            </div>
                                            <?php endif; ?>
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="fallback">
                                                <input name="file" type="file" required />
                                            </div>
                                            <hr>
                                            <div class="clearfix"></div>
                                            <button class="btn btn-primary mr-3" type="submit">Upload Proof Of Payment</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="block form-block mb-4">
                            <div class="block-heading">
                                <h5>Bank Account To Send Money (<?php echo e($currency); ?><?php echo e(number_format($pledgeTrackerSending->amount)); ?>)</h5>
                            </div>
                            <?php if($userBankAccountOk): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <h5 class="text-center" style="color: #ffffff"><i class="fa fa-money"></i> Active Bank Account</h5>
                                <hr>
                                <p>Bank: <?php echo e($bankAccount->bank); ?></p>
                                <p>Account Name: <?php echo e($bankAccount->account_name); ?></p>
                                <p>Account Number: <?php echo e($bankAccount->account_number); ?></p>
                                <hr>
                                <p><?php echo e($user->first_name); ?> will be sending
                                    <?php echo e($currency); ?><?php echo e(number_format($pledgeTrackerSending->amount)); ?>, Please note payment needs to done and confirmed before
                                    <?php echo e(date('l jS \of F Y h:i:s A', strtotime('+ 1 day',$dueDate))); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</section>