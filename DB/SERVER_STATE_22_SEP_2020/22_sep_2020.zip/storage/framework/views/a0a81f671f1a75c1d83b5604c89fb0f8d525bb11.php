<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta content="ie=edge" http-equiv="x-ua-compatible">
        <meta content="template language" name="keywords">
        <meta content="Design_Gurus" name="author">
        <meta content="WOW Admin dashboard html template" name="description">
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <title><?php echo e($pageTitle); ?></title>

        <!--favicon-->
        <link href="<?php echo e(asset('favicon.png')); ?>" rel="shortcut icon">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!--Preloader-CSS-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/preloader/preloader.css')); ?>">

        <!--bootstrap-4-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

        <!--Custom Scroll-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/customScroll/jquery.mCustomScrollbar.min.css')); ?>">
        <!--Font Icons-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/simple-line/css/simple-line-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/dripicons/dripicons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/ionicons/css/ionicons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/eightyshades/eightyshades.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/fontawesome/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/foundation/foundation-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/metrize/metrize.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/typicons/typicons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/icons/weathericons/css/weather-icons.min.css')); ?>">

        <!--Date-range-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/date-range/daterangepicker.css')); ?>">
        <!--Drop-Zone-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/dropzone/dropzone.css')); ?>">
        <!--Full Calendar-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/full-calendar/fullcalendar.min.css')); ?>">
        <!--Normalize Css-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/normalize.css')); ?>">
        <!--Main Css-->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    </head>