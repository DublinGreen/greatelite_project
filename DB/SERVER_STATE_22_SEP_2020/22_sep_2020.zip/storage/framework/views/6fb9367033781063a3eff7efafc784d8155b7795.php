<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('body'); ?>
<?php echo $__env->yieldContent('footer'); ?>
