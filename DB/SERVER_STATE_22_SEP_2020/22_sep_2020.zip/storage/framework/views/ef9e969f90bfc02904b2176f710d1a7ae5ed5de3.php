<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('nav'); ?>
<?php echo $__env->yieldContent('body'); ?>
<?php echo $__env->yieldContent('footer'); ?>
