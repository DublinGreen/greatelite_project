<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Log;
use DB;

use Sms\EbulkSms;
use App\User;
use App\Pledges;
use App\PledgeTracker;

require(__DIR__ . '/../EbulkSms.php');

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    private function sendMergedSms($user)
    {
        $username = env('SMS_USERNAME');
        $apikey = env('SMS_API_KEY');
        $sendername = env('SMS_TITLE');
        $recipients = $user->mobile;
        $flash = 0;
        $appName = env('APP_NAME');
        $composedMessage = "{$user->first_name} you have been merged to make payment. Login into your Greatelite account for user details.";
        //echo ($composedMessage);
        $message = substr($composedMessage, 0, 160); //Limit this message to one page.
        $sms = new EbulkSms();

        #Use the next line for HTTP POST with JSON
        $result = $sms->useJSON(env('SMS_JSON_URL'), $username, $apikey, $flash, $sendername, $message, $recipients);
    }
    
    private function sendRecommitSms($user)
    {
        $username = env('SMS_USERNAME');
        $apikey = env('SMS_API_KEY');
        $sendername = env('SMS_TITLE');
        $recipients = $user->mobile;
        $flash = 0;
        $appName = env('APP_NAME');
        $composedMessage = "{$user->first_name} your pledge is due. You need to recommit and fulfill another pledge. To be withdraw due pledge.";
        //echo ($composedMessage);
        $message = substr($composedMessage, 0, 160); //Limit this message to one page.
        $sms = new EbulkSms();

        #Use the next line for HTTP POST with JSON
        $result = $sms->useJSON(env('SMS_JSON_URL'), $username, $apikey, $flash, $sendername, $message, $recipients);
    }

    private function missedMergedOpportunityNotPaidRegistrationFee($user)
    {
        $username = env('SMS_USERNAME');
        $apikey = env('SMS_API_KEY');
        $sendername = env('SMS_TITLE');
        $recipients = $user->mobile;
        $flash = 0;
        $appName = env('APP_NAME');
        $composedMessage = "{$user->first_name} you have been missed a merge opportunity because you not paid the registration fee.";
        //echo ($composedMessage);
        $message = substr($composedMessage, 0, 160); //Limit this message to one page.
        $sms = new EbulkSms();


        if ($user->send_missed_merged_sms == 'NO') {
            #Use the next line for HTTP POST with JSON
            $result = $sms->useJSON(env('SMS_JSON_URL'), $username, $apikey, $flash, $sendername, $message, $recipients);
            $user->send_missed_merged_sms = 'YES';
            $user->save();
        }
    }

    private function matchToAReceiverThatHasNotPaidAnyAmount()
    {
        // Log::info('Running job to matchToReceive');

        $toReceive = null;
        $userToReceive = null;
        $status = 'PAID';
        $currentDate = date("Y-m-d H:i:s", strtotime("now"));
        $nextDate = date("Y-m-d H:i:s", strtotime("+1 day"));
        $dueDate = date("Y-m-d H:i:s", strtotime("+5 day"));

        echo ("<br>Current Date :" . $currentDate . "<br>");
        // Log::info($currentDate);
        $duePledges = Pledges::where('status', '=', $status)
            ->where('when_due', '<=', $currentDate)
            ->where('process', '=', 'INCOMPLETE')
            ->where('can_withdraw', '=', 'YES')
            ->take(1)
            // ->toSql();
            ->get();

        echo ("<hr>");
        print_r($duePledges);
        echo ("<hr>");
        // exit();
        // need to check if you already have a pledge paid, so withdrawal is good
        if (!empty($duePledges)) {
            // Got due pledges
            foreach ($duePledges as $pledge) {

                $toReceive = $pledge->amount + $pledge->interest + $pledge->bonus_to_collect;
                $userToReceive = User::find($pledge->user_id);

                $usersToPayPledges = Pledges::where('status', '=', 'NOT PAYED')
                    ->where('amount', '<=', $toReceive)
                    // ->where('amount_paid', '!=', 0)
                    ->where('amount_paid', '=', 0)
                    ->where('user_id', '!=', $userToReceive->id)
                    ->get();
                // ->toSql();

                echo ("<hr>");
                print_r($usersToPayPledges);
                echo ("<hr>");
                Log::info($usersToPayPledges);
                // exit();

                echo ("<br> toReceive: $toReceive<br>");
                Log::info('<br> toReceive: toReceive<br>');
                // exit();
                if (!empty($usersToPayPledges)) {
                    // echo count($twoUsersToPayPledges);
                    static $moneyCounter = 0;
                    static $moneyFinalCounter = 0;
                    static $total = 0;
                    echo ("<br>$moneyCounter<br>");

                    foreach ($usersToPayPledges as $userToPayPledge) {
                        $moneyCounter = $userToPayPledge->amount + $moneyCounter;
                        $userToPayData = User::find($userToPayPledge->user_id);

                        if ($userToPayData->registration_fee == 'PAID' && $userToPayData->confirm_mobile == 'YES' && $userToPayData->agreed_to_terms == 'YES') {
                            if ($moneyCounter <= $toReceive) {
                                $total += $userToPayPledge->amount;
                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'amount' => $userToPayPledge->amount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $userToPayPledge->amount;
                                $userToPayPledge->status = 'PAID';
                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();
                                echo ("<br>send alert to sender {$userToPayPledge->amount}<br>");
                                // Log::info("<br>send alert to sender {$userToPayPledge->amount}<br>");

                                $userSendingMoney = User::find($userToPayPledge->user_id);
                                $this->sendMergedSms($userSendingMoney);
                            } else {
                                $lastAmount = $toReceive - $total;

                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'type' => 'PLEDGE',
                                    'amount' => $lastAmount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $lastAmount;

                                if ($lastAmount == $userToPayPledge->amount) {
                                    $userToPayPledge->status = 'PAID';
                                } else {
                                    $userToPayPledge->status = 'PAYING';
                                }

                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();

                                echo ("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                echo ("<br>total {$total}<br>");
                                // Log::info("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                // Log::info("<br>total {$total}<br>");

                                if (!empty($pledge->referrer_id) && $pledge->referrer_bonus == 0) {
                                    $userToGetBonusPledge = Pledges::where('status', '!=', 'NOT PAYED')
                                        ->where('process', '=', 'INCOMPLETE')
                                        ->where('user_id', '=', $pledge->referrer_id)
                                        ->where('referrer_bonus', '=', 0)
                                        ->get();

                                    if (!empty($userToGetBonusPledge)) {
                                        // add current bonus_to_collect and referrer_bonus
                                        $userToGetBonusPledge->bonus_to_collect = $userToGetBonusPledge->bonus_to_collect + $pledge->referrer_bonus;

                                        $pledge->paid_bonus = 'YES'; // ADDEDED BONUS USER NOT PAYED PLEDGE
                                        $pledge->save();
                                        $saved = $userToGetBonusPledge->save();
                                    }
                                }
                                $pledge->process = 'COMPLETE';

                                $pledge->save();
                                // Log::info("<br>MATCHING SUCCES<br>");
                                break;
                            }
                        } else {
                            $this->missedMergedOpportunityNotPaidRegistrationFee($userToPayData);
                        }
                    }
                }
            }
        }
    }

    private function matchToAReceiverThatHasNotPaidSomeAmount()
    {
        // Log::info('Running job to matchToReceive');

        $toReceive = null;
        $userToReceive = null;
        $status = 'PAID';
        $currentDate = date("Y-m-d H:i:s", strtotime("now"));
        $nextDate = date("Y-m-d H:i:s", strtotime("+1 day"));
        $dueDate = date("Y-m-d H:i:s", strtotime("+5 day"));

        echo ("<br>Current Date :" . $currentDate . "<br>");
        // Log::info($currentDate);
        $duePledges = Pledges::where('status', '=', $status)
            ->where('when_due', '<=', $currentDate)
            ->where('process', '=', 'INCOMPLETE')
            ->where('can_withdraw', '=', 'YES')
            ->take(1)
            // ->toSql();
            ->get();

        echo ("<hr>");
        print_r($duePledges);
        echo ("<hr>");
        // exit();
        // need to check if you already have a pledge paid, so withdrawal is good
        if (!empty($duePledges)) {
            // Got due pledges
            foreach ($duePledges as $pledge) {

                $toReceive = $pledge->amount + $pledge->interest + $pledge->bonus_to_collect;
                $userToReceive = User::find($pledge->user_id);

                $usersToPayPledges = Pledges::where('status', '!=', $status)
                    ->where('amount_paid', '<=', $toReceive)
                    ->get();
                // ->toSql();

                echo ("<hr>");
                print_r($usersToPayPledges);
                echo ("<hr>");
                Log::info($usersToPayPledges);
                // exit();

                echo ("<br> toReceive: $toReceive<br>");
                Log::info('<br> toReceive: toReceive<br>');
                if (!empty($usersToPayPledges)) {
                    // echo count($twoUsersToPayPledges);
                    static $moneyCounter = 0;
                    static $moneyFinalCounter = 0;
                    static $total = 0;
                    echo ("<br>$moneyCounter<br>");

                    foreach ($usersToPayPledges as $userToPayPledge) {
                        $moneyCounter = $userToPayPledge->amount + $moneyCounter;
                        $userToPayData = User::find($userToPayPledge->user_id);

                        if ($userToPayData->registration_fee == 'PAID' && $userToPayData->confirm_mobile == 'YES' && $userToPayData->agreed_to_terms == 'YES') {
                            if ($moneyCounter <= $toReceive) {
                                $total += $userToPayPledge->amount;
                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'amount' => $userToPayPledge->amount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $userToPayPledge->amount_paid + ($userToPayPledge->amount - $userToPayPledge->amount_paid);
                                $userToPayPledge->status = 'PAID';
                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();
                                echo ("<br>send alert to sender {$userToPayPledge->amount}<br>");
                                // Log::info("<br>send alert to sender {$userToPayPledge->amount}<br>");

                                $userSendingMoney = User::find($userToPayPledge->user_id);
                                $this->sendMergedSms($userSendingMoney);
                            } else {
                                $lastAmount = $toReceive - $total;

                                $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $pledge->id,
                                    'type' => 'PLEDGE',
                                    'amount' => $lastAmount,
                                    'user_sending' => $userToPayPledge->user_id,
                                    'user_receiving' => $userToReceive->id,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();

                                $userToPayPledge->amount_paid = $lastAmount;

                                if ($lastAmount == $userToPayPledge->amount) {
                                    $userToPayPledge->status = 'PAID';
                                } else {
                                    $userToPayPledge->status = 'PAYING';
                                }

                                $userToPayPledge->when_due = $dueDate;
                                $userToPayPledge->save();

                                echo ("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                echo ("<br>total {$total}<br>");
                                // Log::info("<br>FINAL DIFFERENT {$lastAmount}<br>");
                                // Log::info("<br>total {$total}<br>");

                                if (!empty($pledge->referrer_id) && $pledge->referrer_bonus == 0) {
                                    $userToGetBonusPledge = Pledges::where('status', '!=', 'NOT PAYED')
                                        ->where('process', '=', 'INCOMPLETE')
                                        ->where('user_id', '=', $pledge->referrer_id)
                                        ->where('referrer_bonus', '=', 0)
                                        ->get();

                                    if (!empty($userToGetBonusPledge)) {
                                        // add current bonus_to_collect and referrer_bonus
                                        $userToGetBonusPledge->bonus_to_collect = $userToGetBonusPledge->bonus_to_collect + $pledge->referrer_bonus;

                                        $pledge->paid_bonus = 'YES'; // ADDEDED BONUS USER NOT PAYED PLEDGE
                                        $pledge->save();
                                        $saved = $userToGetBonusPledge->save();
                                    }
                                }
                                $pledge->process = 'COMPLETE';

                                $pledge->save();
                                // Log::info("<br>MATCHING SUCCES<br>");
                                break;
                            }
                        } else {
                            $this->missedMergedOpportunityNotPaidRegistrationFee($userToPayData);
                        }
                    }
                }
            }
        }
    }
    
    private function removeMergerUsersThatHasNotPaidInDueTimeAndGetUserYetToBeMergedOrNotFullyMerged(){
        $toReceive = null;
        $userToReceive = null;
        $currentDate = date("Y-m-d H:i:s", strtotime("now"));
        $nextDate = date("Y-m-d H:i:s", strtotime("+1 day"));
        $dueDate = date("Y-m-d H:i:s", strtotime("+5 day"));

        echo ("<br>Next Date :" . $nextDate . "<br>");

        $dueMergedPledgeTracker = DB::select(DB::raw("select * from pledge_tracker where status = 'NOT CONFIRMED' and created_at <= :due_date_param"), array(
                'due_date_param' => $nextDate
            )); 
            
        $pledgesThatHasNotPaidInFullOrNotPaidAtAll = DB::select(DB::raw("SELECT * FROM `pledges` WHERE amount != amount_paid"), array());     
            
        if(!empty($dueMergedPledgeTracker)){
            static $counter = 0;    
            
            foreach ($dueMergedPledgeTracker as $item) {
                
                if(!empty($pledgesThatHasNotPaidInFullOrNotPaidAtAll[$counter])){
                    
                    $userPledgeObj = $pledgesThatHasNotPaidInFullOrNotPaidAtAll[$counter];
                    
                    $amountToPay = $userPledgeObj->amount = $userPledgeObj->amount_paid;
                    
                    if($amountToPay <= $item->amount){
                        // good to remerge and mark former merge

                        $userToMarkStatusAsDispute = User::find($item->user_sending);
                        if(!empty($userToMarkStatusAsDispute)){
                            $pledgeTrackerTempObj = PledgeTracker::find($item->id);
                            $pledgeTrackerTempObj->status = 'REMERGED';
                            $pledgeTrackerTempObj->save();
                            
                            $pledgeObj = Pledges::find($userPledgeObj->id);
                            $pledgeObj->amount_paid = $pledgeObj->$pledgeObj + $amountToPay;
                            $pledgeObj->save();
                            
                            $userToMarkStatusAsDispute->status = 'DISPUTE';
                            $userToMarkStatusAsDispute->save();
                            
                             $pledgeTracker = PledgeTracker::create([
                                    'pledge_id' => $userPledgeObj->id,
                                    'type' => 'PLEDGE',
                                    'amount' => $amountToPay,
                                    'user_sending' => $userPledgeObj->user_id,
                                    'user_receiving' => $item->user_receiving,
                                    'status' => 'NOT CONFIRMED'
                                ]);
                                $saved = $pledgeTracker->save();
                        }
                        
                        //echo("<br>$userToMarkStatusAsDispute->first_name<br>");
                    }
                }
                
                 //remerge with other users that has not paid full
                 echo("<br>{$item->amount}<br>");
                 $counter++;
             }  
             
            print_r($dueMergedPledgeTracker);  
            echo("<br>" . count($dueMergedPledgeTracker) . "<br>");
        }    

        

    }
    
    private function removeMergerUsersThatHasDidNotPayInDueTimeAndMergeWithUsersNoNotFullyPaidPledge(){
        $toReceive = null;
        $userToReceive = null;
        $currentDate = date("Y-m-d H:i:s", strtotime("now"));
        $nextDate = date("Y-m-d H:i:s", strtotime("+1 day"));
        $dueDate = date("Y-m-d H:i:s", strtotime("+5 day"));

        echo ("<br>Next Date :" . $nextDate . "<br>");

        $dueMergedPledgeTracker = DB::select(DB::raw("select * from pledge_tracker where status = 'NOT CONFIRMED' and created_at <= :due_date_param and proof  IS NULL"), array(
                'due_date_param' => $nextDate
            )); 
            
        $pledgesThatHasNotPaidInFullOrNotPaidAtAll = DB::select(DB::raw("SELECT * FROM `pledges` WHERE amount != amount_paid"), array()); 
        
        if(!empty($dueMergedPledgeTracker)){
            static $counter = 0;    
            
            foreach ($dueMergedPledgeTracker as $item) {
                //# change user dispute to DISPUTE
                $userToMarkStatusAsDispute = User::find($item->user_sending);
                // echo("<br><hr>");
                // print_r($userToMarkStatusAsDispute);
                // echo("<br><hr>");
                // // exit();
                $userToMarkStatusAsDispute->status = 'DISPUTE';
                $userToMarkStatusAsDispute->save();
                
                // # change status of pledgetracker to REMERGED
                $pledgeTrackerTempObj = PledgeTracker::find($item->id);
                $amountToRemerge = $pledgeTrackerTempObj->amount;
                // echo("<br><hr>");
                // print_r($pledgeTrackerTempObj);
                // echo("<br><hr>");
                // exit();
                $pledgeTrackerTempObj->status = 'REMERGED';
                $pledgeTrackerTempObj->save();
                
                # FIND PLEDGES THAT CAN BE USED FOR REMERGE 
                $pledgesThatCanPayCurrentTracker = DB::select(DB::raw("SELECT * FROM `pledges` WHERE amount != amount_paid AND status = 'PAYING'"), array());
                
                echo('MAIN >>>> ' . $amountToRemerge . "TO REMEGE <br>");
                $totalCounter = 0;
                foreach($pledgesThatCanPayCurrentTracker as $incompletePleges){
                    $amountToPay = $incompletePleges->amount - $incompletePleges->amount_paid;
                    
                    echo($amountToPay . "<br>");
                    
                    if($amountToRemerge <= $amountToPay){
                        if($totalCounter <= $amountToRemerge){
                            echo("LETS GO!!!");   
                            
                        //   print_r($item);
                        //   echo("<br><hr><br>");
                        //   echo("<br><hr><br>");
                        //   exit();
                           
                          // # create new pledge tracker
                          $pledgeTracker = PledgeTracker::create([
                                'pledge_id' => $item->id,
                                'type' => 'PLEDGE',
                                'amount' => $amountToRemerge,
                                'user_sending' => $incompletePleges->user_id,
                                'user_receiving' => $item->user_receiving,
                                'status' => 'NOT CONFIRMED'
                            ]);
                            
                            // echo("<hr>");
                            // print_r($pledgeTracker);
                            // echo("<hr>");
                            $saved = $pledgeTracker->save();
                            
                            // #update user_sending pledge
                            $pledgeToUpdate = Pledges::where('user_id', '=', $incompletePleges->user_id)
                            ->where('process', '=', 'INCOMPLETE')
                            ->where('status', '=', 'PAYING')
                            ->where('can_withdraw', '=', 'NO')
                            ->take(1)
                            // ->toSql();
                            ->get();
                            
                            $pledgeToUpdateObj = $pledgeToUpdate[0];
                            print_r($pledgeToUpdateObj);
                            echo("<br><hr><br>");
                            echo("<br><hr><br>");
                            
                            $pledgeToUpdateObj->amount_paid = $pledgeToUpdateObj->amount_paid + $amountToRemerge;
                            $pledgeToUpdateObj->save();
                            
                            print_r($pledgeToUpdateObj);
                            echo("<br><hr><br>");
                            echo("<br><hr><br>");
                            
                            $userSendingMoney = User::find($incompletePleges->user_id);
                            $this->sendMergedSms($userSendingMoney);

                            // exit();
                            // send sms
                        }
                    }
                    $totalCounter = $totalCounter + $amountToPay;
                }
 
                 //remerge with other users that has not paid full
                //  echo("<br>{$item->amount}<br>");
                 $counter++;
             }  
             
            // print_r($dueMergedPledgeTracker);  
            // echo("<br>" . count($dueMergedPledgeTracker) . "<br>");
        }    
    }
    
    private function sendSmsToUserThatPledgeIsDue()
    {

        $currentDate = date("Y-m-d H:i:s", strtotime("+ 1 hour"));
        echo ("<br>Current Date :" . $currentDate . "<br>");

        $duePledges = Pledges::where('when_due', '<=', $currentDate)
            ->where('process', '=', 'COMPLETE')
            ->where('can_withdraw', '=', 'NO')
            ->get();

        if (!empty($duePledges)) {
            foreach ($duePledges as $pledge) {
                echo ("<br> ID : $pledge->id , Referrer_id : $pledge->referrer_id <br>");

                $userToGetBonusPledge = Pledges::where('status', '!=', 'NOT PAYED')
                    ->where('process', '=', 'INCOMPLETE')
                    ->where('user_id', '=', $pledge->referrer_id)
                    ->where('referrer_bonus', '=', 0)
                    ->get();

                if (!empty($userToGetBonusPledge[0])) {

                    $singleUserToGetBonus = $userToGetBonusPledge[0];
                    echo ("PLEDGE TO GET BONUS $singleUserToGetBonus->id ");

                    $singleUserToGetBonus->bonus_to_collect = $singleUserToGetBonus->bonus_to_collect + $pledge->referrer_bonus;

                    $singleUserToGetBonus->save();

                    $pledge->paid_bonus = 'YES';
                }
                $user = User::find($pledge->user_id);
                if($pledge->sent_recommit_sms == 'NO'){
                    $this->sendRecommitSms($user);   
                    $pledge->sent_recommit_sms = 'YES';
                }
                
                
                $pledge->save();
            }
        }
    }
    
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {

        $schedule->call(function () {
            // your schedule code
            Log::info('Running scheduler for matching');
            //$this->sendSmsToUserThatPledgeIsDue(); 
            
            //$this->removeMergerUsersThatHasDidNotPayInDueTimeAndMergeWithUsersNoNotFullyPaidPledge();
            //$this->matchToAReceiverThatHasNotPaidAnyAmount();
            //$this->removeMergerUsersThatHasNotPaidInDueTimeAndGetUserYetToBeMergedOrNotFullyMerged();
            Log::info('Ending scheduler for matching');
        })->everyMinute();
    }

    /**
     * Register the Closure based commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        require base_path('routes/console.php');
    }
}
