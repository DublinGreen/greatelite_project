<!--Page Container-->
<section class="page-container" id="profileBlock">
    <div class="page-content-wrapper">
        <!--Header Fixed-->
        <div class="header fixed-header">
            <div class="container-fluid" style="padding: 10px 25px">
                <div class="row">
                    <div class="col-9 col-md-6 d-lg-none">
                        <a id="toggle-navigation" href="javascript:void(0);" class="icon-btn mr-3"><i class="fa fa-bars"></i></a>
                        <span class="logo">Great Elites</span>
                    </div>
                    <div class="col-lg-8 d-none d-lg-block">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Great Elites <?php echo e($pageTitle); ?></a></li>
                        </ol>
                    </div>
                    <div class="col-3 col-md-6 col-lg-4">
                        <!-- <a href="javascript:void(0);" class="btn btn-primary btn-round pull-right d-none d-md-block">Buy Theme Now</a> -->
                    </div>
                </div>
            </div>
        </div>


        <!--Main Content-->
        <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title">
                            <h4>Pledge</h4>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="block form-block mb-4">
                            <div class="block-heading">
                                <h5>{{fullName}}
                                    <?php if($user->confirm_mobile == 'YES'): ?>
                                    <span class="badge badge-success">VERIFIED</span>
                                    <?php endif; ?>

                                    <?php if($user->confirm_mobile == 'NO'): ?>
                                    <span class="badge badge-warning">NOT VERIFIED</span>
                                    <br><br>
                                    <p class="text-muted">Verify account by adding a valid mobile number
                                        <a href="<?php echo e($appUrl); ?>profile">Verify Account</a>
                                    </p>
                                    <?php endif; ?>

                                </h5>
                            </div>

                            <form action="<?php echo e(url('pledge/')); ?>" method="post" class="horizontal-form">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="user" value="<?php echo e($user->id); ?>">
                                <?php if($user->registration_fee == 'NOT PAID'): ?>
                                <input type="hidden" name="registration_fee" value="<?php echo e($registration_fee); ?>">
                                <?php endif; ?>

                                <?php if($user->registration_fee == 'PAID'): ?>
                                <input type="hidden" name="registration_fee" value="0">
                                <?php endif; ?>

                                <p class="text-muted">Withdrawal for this investment will be due in <?php echo e($investment_duration); ?>. After pledge is fulfilled.</p>
                                <p class="text-muted">Please note to withdraw your investment when due. <strong>You need to recommit (pledge again).</strong></p>
                                <?php if(!empty($pledgeMessage)): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <p><strong>Success : </strong> <?php echo e($pledgeMessage); ?></p>
                                    <button style="margin-top: -30px" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>

                                <?php if(!empty($pledgeWarning)): ?>
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <p><strong>Warning : </strong> <?php echo e($pledgeWarning); ?></p>
                                    <button style="margin-top: -30px" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>

                                <br>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Pledge Options </label>
                                        <select v-model="amount" required class="custom-select form-control" name="pledge">
                                            <option value="0">Pledge Amount Options</option>
                                            <?php $__currentLoopData = $pledgeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->amount); ?>"><?php echo e($currency); ?><?php echo e(number_format("$item->amount")); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <?php if($user->registration_fee == 'NOT PAID'): ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <p><strong>NOTE : </strong> On first pledge, you are to pay a one time fee of <?php echo e($currency); ?><?php echo e(number_format($registration_fee)); ?></p>
                                            <button style="margin-top: -30px" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <h2>
                                        <?php echo e($currency); ?>{{amountFormated}}

                                        <?php if($user->registration_fee == 'NOT PAID'): ?>
                                        + <?php echo e($currency); ?>{{registrationFee}} <span class="text-muted" style="font-size: 0.5em">(registration fee)</span>
                                        <?php endif; ?>
                                    </h2>
                                </div>
                                <hr>
                                <button class="btn btn-primary" style="font-size: 1.2em;" type="submit"><i class="dripicons-heart"></i> Pledge</button>
                            </form>
                        </div>
                    </div>

                    <div class="col-md-6">
                    </div>

                </div>
            </div>
        </div>
    </div>

</section>

<script>
    var vm = new Vue({
        el: '#profileBlock',
        created: function() {
            if (this.sex == 'MALE') {
                this.isMale = true;
            } else {
                this.isFemale = true;
            }
        },
        data: {
            firstName: "<?php echo e($user->first_name); ?>",
            middleName: "<?php echo e($user->middle_name); ?>",
            lastName: "<?php echo e($user->last_name); ?>",
            email: "<?php echo e($user->email); ?>",
            mobile: "<?php echo e($user->mobile); ?>",
            sex: "<?php echo e($user->sex); ?>",
            userRef: "<?php echo e($user->user_ref); ?>",
            registrationFeePaid: "<?php echo e($user->registration_fee); ?>",
            amount: 0,
            amountFormated: "0",
            registrationFee: "<?php echo e($registration_fee); ?>",
            isMale: false,
            isFemale: false,
        },
        watch: {
            sex(value) {
                console.log(value);
                if (this.sex == 'MALE') {
                    this.isMale = true;
                } else {
                    this.isFemale = true;
                }
            },
            amount(value) {
                this.amountFormated = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
        },
        computed: {
            fullName: function() {
                return this.firstName + " " + this.lastName;
            }
        }
    })
</script>

<script>
    function copyRefeerLink() {
        var copyText = document.getElementById("myInput");
        copyText.select();
        copyText.setSelectionRange(0, 99999)
        document.execCommand("copy");
        // alert("Copied the text: " + copyText.value);
    }
</script>