<body>

    <!---Preloader Starts Here--->
    <div id="ip-container" class="ip-container">
        <header class="ip-header">
            <h1 class="ip-logo text-center"><img class="img-fluid" src="<?php echo e($appUrl); ?>assets/images/logo-c.png" alt="" class="ip-logo text-center" /></h1>
            <div class="ip-loader">
                <svg class="ip-inner" width="60px" height="60px" viewBox="0 0 80 80">
                    <path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z" />
                    <path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z" />
                </svg>
            </div>
        </header>
    </div>
    <!---Preloader Ends Here--->

    <section style="background: url(<?php echo e($appUrl); ?>assets/images/macbook-laptop-ipad-apple-38519.jpeg?w=940&amp;h=650&amp;auto=compress&amp;cs=tinysrgb);background-size: cover">
        <div class="height-100-vh bg-primary-trans">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="login-div">
                            <p class="logo mb-1"><a href="<?php echo e($appUrl); ?>" target="blank"><i class="fa fa-home"></i></a><?php echo e($appName); ?> - Password Recovery</p>
                            <p class="mb-4" style="color: #a5b5c5">Reset your password by entering your user email.</p>
                            <form method="post" id="needs-validation" action="<?php echo e(url('passwordRecovery/')); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                <?php if(!empty($message)): ?>
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <p><strong>Note : </strong> <?php echo e($message); ?></p>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <?php endif; ?>

                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input name="email" class="form-control input-lg" placeholder="email" type="email" required>
                                    <div class="invalid-feedback">This field is required.</div>
                                </div>

                                <button class="btn btn-primary mt-2">Recover Password</button>

                                <small class="text-muted mt-5 mb-1 d-block"><i class="fa fa-user"></i> <a href="<?php echo e($appUrl); ?>login">Login</a></small>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>