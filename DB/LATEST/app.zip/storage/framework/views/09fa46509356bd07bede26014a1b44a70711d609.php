<!--Navigation-->
<nav id="navigation" class="navigation-sidebar bg-primary">
    <div class="navigation-header">
        <a href="#"><span class="logo"><?php echo e($appName); ?></span></a>
        <!--<img src="logo.png" alt="logo" class="brand" height="50">-->
    </div>

    <!--Navigation Profile area-->
    <div class="navigation-profile">
        <img class="profile-img rounded-circle" src="<?php echo e($appUrl); ?>assets/logo.png" alt="profile image">

        <?php if(empty($user)): ?>
        <?php echo e(exit()); ?>

        <?php endif; ?>
        <h4 class="name"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> </h4>
        <span class="designation"><?php echo e($user->email); ?></span>

        <a id="show-user-menu" href="javascript:void(0);" class="circle-white-btn profile-setting"><i class="fa fa-cog"></i></a>

        <!--logged user hover menu-->
        <div class="logged-user-menu bg-white">
            <div class="avatar-info">

                <?php if($user->sex == 'MALE'): ?>
                <img class="profile-img rounded-circle" src="<?php echo e($appUrl); ?>assets/images/male.jpeg" alt="profile image">
                <?php endif; ?>

                <?php if($user->sex == 'FEMALE'): ?>
                <img class="profile-img rounded-circle" src="<?php echo e($appUrl); ?>assets/images/female.png" alt="profile image">
                <?php endif; ?>
                <h4 class="name"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h4>
                <?php if($user->confirm_mobile == 'YES'): ?>
                <span style="color: #ffffff" class="badge badge-success designation">VERIFIED</span>
                <?php endif; ?>

                <?php if($user->confirm_mobile == 'NO'): ?>
                <span class="badge badge-warning designation">NOT VERIFIED</span>
                <?php endif; ?>
            </div>

            <ul class="list-unstyled">
                <li>
                    <a href="<?php echo e($appUrl); ?>profile">
                        <i class="ion-ios-person-outline"></i>
                        <span>My Profile</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="ion-ios-locked-outline"></i>
                        <span>Change Password</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e($appUrl); ?>logout">
                        <i class="ion-log-out"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!--Navigation Menu Links-->
    <div class="navigation-menu">

        <ul class="menu-items custom-scroll">
            <li>
                <a href="javascript:void(0);" class="have-submenu active">
                    <span class="icon-thumbnail"><i class="dripicons-browser"></i></span>
                    <span class="title">Dashboard</span>
                </a>
                <!--Submenu-->
                <ul class="sub-menu">
                    <li>
                        <a href="<?php echo e($appUrl); ?>dashboard" class="active">
                            <span class="icon-thumbnail"><i class="dripicons-browser"></i></span>
                            <span class="title">Main Dashboard</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0);" class="have-submenu">
                    <span class="icon-thumbnail"><i class="dripicons-user"></i></span>
                    <span class="title">Profile</span>
                </a>
                <!--Submenu-->
                <ul class="sub-menu">
                    <li>
                        <a href="<?php echo e($appUrl); ?>profile">
                            <span class="title">Manage Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($appUrl); ?>downlines">
                            <span class="title">Downlines</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0);" class="have-submenu">
                    <span class="icon-thumbnail"><i class="dripicons-heart"></i></span>
                    <span class="title">Pledge</span>
                </a>
                <!--Submenu-->
                <ul class="sub-menu">
                    <li>
                        <a href="<?php echo e($appUrl); ?>pledge">
                            <span class="title">New Pledge</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($appUrl); ?>unpaidPledge">
                            <span class="title">Unpaid Pledge</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($appUrl); ?>paidPledge">
                            <span class="title">Paid Pledges</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e($appUrl); ?>mergeList">
                            <span class="title">Merge List</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:void(0);" class="have-submenu">
                    <span class="icon-thumbnail"><i class="fa fa-money"></i></span>
                    <span class="title">Withdrawal</span>
                </a>
                <!--Submenu-->
                <ul class="sub-menu">
                    <li>
                        <a href="#">
                            <span class="title" data-toggle="tooltip" data-placement="left" title="Not due for withdrawal">Withdraw</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="title" data-toggle="tooltip" data-placement="left" title="Not due for withdrawal">All Withdrawals</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="<?php echo e($appUrl); ?>faq">
                    <span class="icon-thumbnail"><i class="dripicons-document"></i></span>
                    <span class="title">FAQ</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e($appUrl); ?>logout">
                    <span class="icon-thumbnail"><i class="dripicons-power"></i></span>
                    <span class="title">Logout</span>
                </a>
            </li>
        </ul>
    </div>
</nav>