<body>

  <!-- start page-wrapper -->
  <div class="page-wrapper">

    <!-- start preloader -->
    <div class="preloader">
      <div class="lds-ripple">
        <div></div>
        <div></div>
      </div>
    </div>
    <!-- end preloader -->

    <!-- Start header -->
    <header id="header" class="site-header header-style-1">
      <nav class="navigation navbar navbar-default">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="open-btn">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(env('APP_URL')); ?>"><img src="assets_public/images/logo2.png" alt></a>
          </div>
          <div id="navbar" class="navbar-collapse collapse navigation-holder">
            <button class="close-navbar"><i class="ti-close"></i></button>
            <ul class="nav navbar-nav">
              <li class="menu-item-has-children">
                <a href="<?php echo e($appUrl); ?>">Home</a>
              </li>
              <li class="menu-item-has-children">
                <a href="<?php echo e($appUrl); ?>about">About</a>
              </li>
              <li class="menu-item-has-children">
                <a href="<?php echo e($appUrl); ?>terms">Terms & Privacy</a>
              </li>
              <!-- <li class="menu-item-has-children">
                <a href="#">Services</a>
                <ul class="sub-menu">
                  <li><a href="services.html">Services</a></li>
                  <li><a href="service-details.html">Service single</a></li>
                </ul>
              </li>
              <li class="menu-item-has-children">
                <a href="#">Projects</a>
                <ul class="sub-menu">
                  <li><a href="projects.html">Projects</a></li>
                  <li><a href="project-details.html">Project single</a></li>
                </ul>
              </li>
              <li class="menu-item-has-children">
                <a href="#">Blog</a>
                <ul class="sub-menu">
                  <li><a href="blog.html">Blog</a></li>
                  <li><a href="blog-grid.html">Blog Grid</a></li>
                  <li><a href="blog-details.html">Blog single</a></li>
                </ul>
              </li> -->
              <li><a href="<?php echo e($appUrl); ?>contactus">Contact</a></li>
            </ul>

          </div><!-- end of nav-collapse -->

          <div class="quote-btn">
            <a href="<?php echo e($appUrl); ?>" class="theme-btn" data-toggle="tooltip" data-placement="left" title="Great Elite is opening 5 September 2020 at 4pm WAT">Get Started</a>
            <!-- <a href="<?php echo e($appUrl); ?>register" class="theme-btn">Register</a>
            <a href="<?php echo e($appUrl); ?>login" class="theme-btn">Login</a> -->
          </div>
        </div><!-- end of container -->
      </nav>
    </header>
    <!-- end of header -->