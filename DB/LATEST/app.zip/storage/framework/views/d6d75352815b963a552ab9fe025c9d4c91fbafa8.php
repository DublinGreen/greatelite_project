<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('page-not-found-pages.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('page-not-found-pages.404', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.page_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>