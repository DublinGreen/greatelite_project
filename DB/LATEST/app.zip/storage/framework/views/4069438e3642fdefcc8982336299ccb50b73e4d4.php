<!--Page Container-->
<section class="page-container" id="profileBlock">
    <div class="page-content-wrapper">
        <!--Header Fixed-->
        <div class="header fixed-header">
            <div class="container-fluid" style="padding: 10px 25px">
                <div class="row">
                    <div class="col-9 col-md-6 d-lg-none">
                        <a id="toggle-navigation" href="javascript:void(0);" class="icon-btn mr-3"><i class="fa fa-bars"></i></a>
                        <span class="logo">Great Elites</span>
                    </div>
                    <div class="col-lg-8 d-none d-lg-block">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Great Elites <?php echo e($pageTitle); ?></a></li>
                        </ol>
                    </div>
                    <div class="col-3 col-md-6 col-lg-4">
                        <!-- <a href="javascript:void(0);" class="btn btn-primary btn-round pull-right d-none d-md-block">Buy Theme Now</a> -->
                    </div>
                </div>
            </div>
        </div>


        <!--Main Content-->
        <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title">
                            <h4>Unpaid Pledge</h4>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="block form-block mb-4">

                            <div class="block table-block mb-4">
                                <div class="block-heading">
                                    <p class="mt-2" style="color: #333333">Pledges that are not due for withdrawal</p>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Status</th>
                                                <th>Amount</th>
                                                <th>Amount Paid</th>
                                                <th>Interest</th>
                                                <th>Referrer Bonus</th>
                                                <th>Referrer Id</th>
                                                <th class="text-left">Pledged Date</th>
                                                <th class="text-right">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pledges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="status pending">
                                                    <?php if($item->status == 'NOT PAYED'): ?>
                                                    NOT MERGED
                                                    <?php endif; ?>
                                                    <?php if($item->status == 'PAYING'): ?>
                                                    MERGED
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($currency); ?> <?php echo e(number_format($item->amount)); ?></td>
                                                <td><?php echo e($currency); ?> <?php echo e(number_format($item->amount_paid)); ?></td>
                                                <td><?php echo e($currency); ?> <?php echo e(number_format($item->interest)); ?></td>
                                                <td><?php echo e($currency); ?> <?php echo e(number_format($item->referrer_bonus)); ?></td>
                                                <td><?php echo e($item->referrer_id); ?></td>
                                                <td class="text-left"><?php echo e(date('l jS \of F Y h:i:s A', strtotime($item->created_at))); ?></td>
                                                <td class="text-right">
                                                    <?php if($item->status == 'PAYING'): ?>
                                                    <a style="color: #ffffff" class="btn btn-success"><i class="fa fa-users"></i> View Merged Users</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</section>

<script>
    var vm = new Vue({
        el: '#profileBlock',
        created: function() {
            if (this.sex == 'MALE') {
                this.isMale = true;
            } else {
                this.isFemale = true;
            }
        },
        data: {
            firstName: "<?php echo e($user->first_name); ?>",
            middleName: "<?php echo e($user->middle_name); ?>",
            lastName: "<?php echo e($user->last_name); ?>",
            email: "<?php echo e($user->email); ?>",
            mobile: "<?php echo e($user->mobile); ?>",
            sex: "<?php echo e($user->sex); ?>",
            userRef: "<?php echo e($user->user_ref); ?>",
            registrationFeePaid: "<?php echo e($user->registration_fee); ?>",
            amount: 0,
            amountFormated: "0",
            registrationFee: "<?php echo e($registration_fee); ?>",
            isMale: false,
            isFemale: false,
        },
        watch: {
            sex(value) {
                console.log(value);
                if (this.sex == 'MALE') {
                    this.isMale = true;
                } else {
                    this.isFemale = true;
                }
            },
            amount(value) {
                this.amountFormated = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
        },
        computed: {
            fullName: function() {
                return this.firstName + " " + this.lastName;
            }
        }
    })
</script>

<script>
    function copyRefeerLink() {
        var copyText = document.getElementById("myInput");
        copyText.select();
        copyText.setSelectionRange(0, 99999)
        document.execCommand("copy");
        // alert("Copied the text: " + copyText.value);
    }
</script>